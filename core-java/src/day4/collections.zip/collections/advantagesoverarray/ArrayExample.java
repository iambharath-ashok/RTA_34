package day4.collections.advantagesoverarray;

public class ArrayExample {

    public static void main(String[] args) {

        // integer array
        int [] numbers = new int[5];// 5 blocks of integer has been allocated

        System.out.println(numbers);

        numbers[2] = 10;

        System.out.println(numbers);



    }
}
